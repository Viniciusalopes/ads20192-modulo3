--
-- PostgreSQL database dump
--

-- Dumped from database version 12.4 (Ubuntu 12.4-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.4 (Ubuntu 12.4-0ubuntu0.20.04.1)

-- Started on 2020-09-16 14:25:45 -03

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 203 (class 1259 OID 32839)
-- Name: empresas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empresas (
    emp_id integer NOT NULL,
    emp_nome character varying(50) NOT NULL
);


ALTER TABLE public.empresas OWNER TO postgres;

--
-- TOC entry 202 (class 1259 OID 32837)
-- Name: empresas_emp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empresas_emp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empresas_emp_id_seq OWNER TO postgres;

--
-- TOC entry 2986 (class 0 OID 0)
-- Dependencies: 202
-- Name: empresas_emp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empresas_emp_id_seq OWNED BY public.empresas.emp_id;


--
-- TOC entry 205 (class 1259 OID 32849)
-- Name: setores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.setores (
    set_id integer NOT NULL,
    set_nome character varying(50) NOT NULL,
    emp_id integer NOT NULL
);


ALTER TABLE public.setores OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 32847)
-- Name: setores_set_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.setores_set_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.setores_set_id_seq OWNER TO postgres;

--
-- TOC entry 2987 (class 0 OID 0)
-- Dependencies: 204
-- Name: setores_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.setores_set_id_seq OWNED BY public.setores.set_id;


--
-- TOC entry 2840 (class 2604 OID 32842)
-- Name: empresas emp_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresas ALTER COLUMN emp_id SET DEFAULT nextval('public.empresas_emp_id_seq'::regclass);


--
-- TOC entry 2841 (class 2604 OID 32852)
-- Name: setores set_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.setores ALTER COLUMN set_id SET DEFAULT nextval('public.setores_set_id_seq'::regclass);


--
-- TOC entry 2978 (class 0 OID 32839)
-- Dependencies: 203
-- Data for Name: empresas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empresas (emp_id, emp_nome) FROM stdin;
1	COUVES Soluções em Tecnologia
\.


--
-- TOC entry 2980 (class 0 OID 32849)
-- Dependencies: 205
-- Data for Name: setores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.setores (set_id, set_nome, emp_id) FROM stdin;
4	Bananas de Pijamas	1
1	Desenvolvimento de doidos	1
5	LKJHGFDS	1
\.


--
-- TOC entry 2988 (class 0 OID 0)
-- Dependencies: 202
-- Name: empresas_emp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empresas_emp_id_seq', 1, true);


--
-- TOC entry 2989 (class 0 OID 0)
-- Dependencies: 204
-- Name: setores_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.setores_set_id_seq', 5, true);


--
-- TOC entry 2843 (class 2606 OID 32846)
-- Name: empresas empresas_emp_nome_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresas
    ADD CONSTRAINT empresas_emp_nome_key UNIQUE (emp_nome);


--
-- TOC entry 2845 (class 2606 OID 32844)
-- Name: empresas empresas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (emp_id);


--
-- TOC entry 2847 (class 2606 OID 32854)
-- Name: setores setores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.setores
    ADD CONSTRAINT setores_pkey PRIMARY KEY (set_id);


--
-- TOC entry 2849 (class 2606 OID 32856)
-- Name: setores setores_set_nome_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.setores
    ADD CONSTRAINT setores_set_nome_key UNIQUE (set_nome);


--
-- TOC entry 2850 (class 2606 OID 32857)
-- Name: setores setores_emp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.setores
    ADD CONSTRAINT setores_emp_id_fkey FOREIGN KEY (emp_id) REFERENCES public.empresas(emp_id);


-- Completed on 2020-09-16 14:25:45 -03

--
-- PostgreSQL database dump complete
--

