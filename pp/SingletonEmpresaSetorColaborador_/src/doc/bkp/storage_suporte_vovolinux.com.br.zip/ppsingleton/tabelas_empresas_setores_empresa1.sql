CREATE TABLE empresas
(
	emp_id SERIAL NOT NULL,
	emp_nome varchar(50) UNIQUE NOT NULL,
	PRIMARY KEY (emp_id)
);

CREATE TABLE setores
(
	set_id SERIAL NOT NULL,
	set_nome varchar(50) UNIQUE NOT NULL,
	emp_id int NOT NULL,
	PRIMARY KEY (set_id),
	FOREIGN KEY (emp_id) REFERENCES empresas (emp_id)
);

INSERT INTO empresas (emp_nome) VALUES ('COUVES Soluções em Tecnologia');
INSERT INTO setores (set_nome, emp_id) VALUES ('Desenvolvimento', 1);

SELECT e.*, s.set_id, s.set_nome
FROM empresas e
INNER JOIN setores s ON e.emp_id = s.emp_id;