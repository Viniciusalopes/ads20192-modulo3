SELECT e.*, s.set_id, s.set_nome FROM empresas e INNER JOIN setores s ON e.emp_id = s.emp_id;
INSERT INTO setores (set_nome, emp_id) VALUES ('Bananas de Pijamas', 1);
SELECT e.*, s.set_id, s.set_nome FROM empresas e INNER JOIN setores s ON e.emp_id = s.emp_id;
INSERT INTO setores (set_nome, emp_id) VALUES ('Desenvolvimento', 1);
SELECT e.*, s.set_id, s.set_nome FROM empresas e INNER JOIN setores s ON e.emp_id = s.emp_id;
INSERT INTO setores (set_nome, emp_id) VALUES ('Eitalalá', 1);
SELECT e.*, s.set_id, s.set_nome FROM empresas e INNER JOIN setores s ON e.emp_id = s.emp_id;


